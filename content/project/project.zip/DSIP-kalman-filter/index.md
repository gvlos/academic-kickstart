---
title: Tennis ball tracking using Kalman filter
summary: Digital Signal and Image Processing, University of Genoa (90520) - Fall 2019 - Final project
tags:
- Machine Learning
date: "2020-02-10T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: "https://github.com/gvlos/DSIP_project"

image:
  caption: Photo by rawpixel on Unsplash
  focal_point: Smart

links:
#url_code: "https://github.com/gvlos/ML_project"
#url_pdf: "https://github.com/gvlos/ML_project/blob/master/Report.pdf"
#url_slides: "https://github.com/gvlos/ML_project/blob/master/Presentation.pdf"
#url_video: ""

# Slides (optional).
#   Associate this project with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides = "example-slides"` references `content/slides/example-slides.md`.
#   Otherwise, set `slides = ""`.
slides: ""
---


